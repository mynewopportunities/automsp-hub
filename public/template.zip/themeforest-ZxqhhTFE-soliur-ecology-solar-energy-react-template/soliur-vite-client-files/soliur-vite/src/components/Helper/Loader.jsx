import React from 'react';

function Loader() {
    return (
    <div className="preloader"></div>
    );
}

export default Loader;
